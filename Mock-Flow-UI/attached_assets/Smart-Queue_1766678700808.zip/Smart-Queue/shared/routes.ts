import { z } from "zod";
import { centers, queue, joinQueueSchema, predictWaitSchema } from "./schema";

export const api = {
  centers: {
    list: {
      method: "GET" as const,
      path: "/api/centers",
      responses: {
        200: z.array(z.custom<typeof centers.$inferSelect>()),
      },
    },
  },
  queue: {
    list: {
      method: "GET" as const,
      path: "/api/queue/:centerId",
      responses: {
        200: z.array(z.custom<typeof queue.$inferSelect>()),
      },
    },
    join: {
      method: "POST" as const,
      path: "/api/join",
      input: joinQueueSchema,
      responses: {
        201: z.custom<typeof queue.$inferSelect>(),
        400: z.object({ message: z.string() }),
      },
    },
    predict: {
      method: "POST" as const,
      path: "/api/predict",
      input: predictWaitSchema,
      responses: {
        200: z.object({
          waitMinutes: z.number(),
          rushLevel: z.enum(["low", "medium", "high"]),
          tip: z.string(),
        }),
      },
    },
    callNext: {
      method: "POST" as const,
      path: "/api/queue/:centerId/next",
      responses: {
        200: z.object({ success: z.boolean() }),
      },
    },
  },
};
