import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// We are using in-memory storage, but we define the schema here for type consistency
// and potential future DB migration.

export const centers = pgTable("centers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  address: text("address").notNull(),
  lat: text("lat").notNull(),
  lng: text("lng").notNull(),
  totalCounters: integer("total_counters").notNull(),
  activeCounters: integer("active_counters").notNull(),
  avgServiceTime: integer("avg_service_time").notNull(), // in minutes
  currentQueueLength: integer("current_queue_length").notNull().default(0),
});

export const queue = pgTable("queue", {
  id: serial("id").primaryKey(),
  centerId: integer("center_id").notNull(),
  tokenNumber: text("token_number").notNull(),
  citizenName: text("citizen_name").notNull(),
  phone: text("phone").notNull(),
  serviceType: text("service_type").notNull(),
  status: text("status").notNull(), // waiting, serving, completed
  counterAssigned: integer("counter_assigned"),
  joinTime: timestamp("join_time").notNull().defaultNow(),
  estimatedWait: integer("estimated_wait").notNull(),
});

export const insertCenterSchema = createInsertSchema(centers).omit({ id: true });
export const insertQueueSchema = createInsertSchema(queue).omit({ id: true, joinTime: true });

export type Center = typeof centers.$inferSelect;
export type InsertCenter = z.infer<typeof insertCenterSchema>;
export type QueueItem = typeof queue.$inferSelect;
export type InsertQueueItem = z.infer<typeof insertQueueSchema>;

export const joinQueueSchema = z.object({
  centerId: z.number(),
  citizenName: z.string().min(1, "Name is required"),
  phone: z.string().min(10, "Phone number required"),
  serviceType: z.string().min(1, "Service type required"),
});

export const predictWaitSchema = z.object({
  centerId: z.number(),
  serviceType: z.string(),
});

export type JoinQueueRequest = z.infer<typeof joinQueueSchema>;
export type PredictWaitRequest = z.infer<typeof predictWaitSchema>;

export interface PredictionResponse {
  waitMinutes: number;
  rushLevel: "low" | "medium" | "high";
  tip: string;
}

export const SERVICES = [
  "Document Verification",
  "New Application",
  "Certificate Collection",
  "Query Resolution",
  "Payment & Fees"
];
