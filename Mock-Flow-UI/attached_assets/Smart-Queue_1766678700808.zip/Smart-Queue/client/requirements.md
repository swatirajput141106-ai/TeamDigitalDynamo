## Packages
framer-motion | Smooth animations for queue updates and transitions
lucide-react | Beautiful icons for UI elements
date-fns | Formatting timestamps

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
