import { useState } from "react";
import { usePredictWait } from "@/hooks/use-queue";
import { SERVICES } from "@shared/schema";
import { Bot, Zap, Clock, TrendingUp } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface AIPredictorProps {
  centerId: number;
}

export function AIPredictor({ centerId }: AIPredictorProps) {
  const [service, setService] = useState<string>("");
  const { mutate, data: prediction, isPending } = usePredictWait();

  const handlePredict = () => {
    if (!service) return;
    mutate({ centerId, serviceType: service });
  };

  return (
    <div className="bg-gradient-to-br from-indigo-50 to-white rounded-2xl border border-indigo-100 p-6 shadow-lg shadow-indigo-500/5 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 -mr-4 -mt-4 w-24 h-24 bg-gradient-to-br from-indigo-200 to-purple-200 rounded-full opacity-20 blur-2xl" />
      
      <div className="relative z-10">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-lg bg-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-600/20">
            <Bot className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-lg text-indigo-950">AI Wait Predictor</h3>
            <div className="flex items-center gap-1.5 text-xs font-medium text-indigo-600 bg-indigo-100 px-2 py-0.5 rounded-full w-fit">
              <Zap className="w-3 h-3" /> Powered by Gemini
            </div>
          </div>
        </div>

        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Not sure when to visit? Let our AI analyze current traffic and historical data to give you the best time.
        </p>

        <div className="space-y-4">
          <Select value={service} onValueChange={setService}>
            <SelectTrigger className="bg-white border-indigo-200 focus:ring-indigo-200 rounded-xl h-11">
              <SelectValue placeholder="Check wait time for..." />
            </SelectTrigger>
            <SelectContent>
              {SERVICES.map((s) => (
                <SelectItem key={s} value={s}>{s}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button 
            onClick={handlePredict} 
            disabled={!service || isPending}
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl h-11 font-medium transition-all shadow-lg shadow-indigo-600/20 hover:shadow-indigo-600/30"
          >
            {isPending ? "Analyzing..." : "Predict Wait Time"}
          </Button>

          {prediction && (
            <div className="mt-4 p-4 bg-white rounded-xl border border-indigo-100 shadow-sm animate-in fade-in slide-in-from-bottom-2">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <Clock className="w-4 h-4" /> Estimated Wait
                </span>
                <span className="text-xl font-bold text-indigo-700">
                  {prediction.waitMinutes} min
                </span>
              </div>
              
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <TrendingUp className="w-4 h-4" /> Rush Level
                </span>
                <span className={cn(
                  "px-2 py-0.5 rounded-full text-xs font-bold uppercase",
                  prediction.rushLevel === "low" ? "bg-green-100 text-green-700" :
                  prediction.rushLevel === "medium" ? "bg-yellow-100 text-yellow-700" :
                  "bg-red-100 text-red-700"
                )}>
                  {prediction.rushLevel}
                </span>
              </div>

              <div className="pt-3 border-t border-dashed border-indigo-100">
                <p className="text-xs text-indigo-800 leading-relaxed italic">
                  "{prediction.tip}"
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
