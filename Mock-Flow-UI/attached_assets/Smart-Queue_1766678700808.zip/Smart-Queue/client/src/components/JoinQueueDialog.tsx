import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { joinQueueSchema, SERVICES, type JoinQueueRequest } from "@shared/schema";
import { useJoinQueue } from "@/hooks/use-queue";
import { Ticket, Sparkles, User, Phone, Briefcase } from "lucide-react";

interface JoinQueueDialogProps {
  centerId: number;
}

export function JoinQueueDialog({ centerId }: JoinQueueDialogProps) {
  const [open, setOpen] = useState(false);
  const { mutate, isPending } = useJoinQueue();
  
  const form = useForm<JoinQueueRequest>({
    resolver: zodResolver(joinQueueSchema),
    defaultValues: {
      centerId,
      citizenName: "",
      phone: "",
      serviceType: "",
    },
  });

  const onSubmit = (data: JoinQueueRequest) => {
    mutate(data, {
      onSuccess: () => {
        setOpen(false);
        form.reset();
      },
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="lg" className="w-full bg-gradient-to-r from-primary to-blue-600 hover:to-blue-700 shadow-xl shadow-primary/20 hover:shadow-primary/30 transition-all duration-300">
          <Ticket className="w-5 h-5 mr-2" />
          Get a Ticket
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px] rounded-2xl border-none shadow-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Sparkles className="w-5 h-5 text-primary" />
            Join the Queue
          </DialogTitle>
          <p className="text-sm text-muted-foreground">Fill in your details to reserve your spot instantly.</p>
        </DialogHeader>

        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 mt-4">
          <div className="space-y-2">
            <Label htmlFor="citizenName" className="flex items-center gap-2">
              <User className="w-4 h-4 text-primary" /> Full Name
            </Label>
            <Input 
              {...form.register("citizenName")} 
              placeholder="John Doe" 
              className="rounded-xl border-border/60 focus:ring-primary/20"
            />
            {form.formState.errors.citizenName && (
              <p className="text-xs text-destructive">{form.formState.errors.citizenName.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone" className="flex items-center gap-2">
              <Phone className="w-4 h-4 text-primary" /> Phone Number
            </Label>
            <Input 
              {...form.register("phone")} 
              placeholder="+1 (555) 000-0000" 
              className="rounded-xl border-border/60 focus:ring-primary/20"
            />
            {form.formState.errors.phone && (
              <p className="text-xs text-destructive">{form.formState.errors.phone.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="serviceType" className="flex items-center gap-2">
              <Briefcase className="w-4 h-4 text-primary" /> Service Required
            </Label>
            <Select onValueChange={(val) => form.setValue("serviceType", val)}>
              <SelectTrigger className="rounded-xl border-border/60 focus:ring-primary/20">
                <SelectValue placeholder="Select a service" />
              </SelectTrigger>
              <SelectContent>
                {SERVICES.map((s) => (
                  <SelectItem key={s} value={s}>{s}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {form.formState.errors.serviceType && (
              <p className="text-xs text-destructive">{form.formState.errors.serviceType.message}</p>
            )}
          </div>

          <Button 
            type="submit" 
            className="w-full rounded-xl py-6 font-semibold bg-primary hover:bg-primary/90"
            disabled={isPending}
          >
            {isPending ? "Issuing Ticket..." : "Join Queue Now"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
