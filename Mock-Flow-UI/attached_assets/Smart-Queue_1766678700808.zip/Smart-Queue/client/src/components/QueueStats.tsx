import { Users, Clock, CheckCircle2 } from "lucide-react";
import { type QueueItem } from "@shared/schema";

interface QueueStatsProps {
  queue: QueueItem[];
  avgServiceTime: number;
}

export function QueueStats({ queue, avgServiceTime }: QueueStatsProps) {
  const waiting = queue.filter((q) => q.status === "waiting").length;
  const serving = queue.filter((q) => q.status === "serving").length;
  const completed = queue.filter((q) => q.status === "completed").length;
  const estWait = waiting * avgServiceTime;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
      <div className="bg-white rounded-xl p-5 border shadow-sm flex items-center gap-4">
        <div className="w-12 h-12 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center">
          <Users className="w-6 h-6" />
        </div>
        <div>
          <p className="text-sm text-muted-foreground font-medium">Waiting</p>
          <h3 className="text-2xl font-bold text-foreground">{waiting} People</h3>
        </div>
      </div>

      <div className="bg-white rounded-xl p-5 border shadow-sm flex items-center gap-4">
        <div className="w-12 h-12 rounded-full bg-amber-50 text-amber-600 flex items-center justify-center">
          <Clock className="w-6 h-6" />
        </div>
        <div>
          <p className="text-sm text-muted-foreground font-medium">Est. Wait</p>
          <h3 className="text-2xl font-bold text-foreground">{estWait} Mins</h3>
        </div>
      </div>

      <div className="bg-white rounded-xl p-5 border shadow-sm flex items-center gap-4">
        <div className="w-12 h-12 rounded-full bg-green-50 text-green-600 flex items-center justify-center">
          <CheckCircle2 className="w-6 h-6" />
        </div>
        <div>
          <p className="text-sm text-muted-foreground font-medium">Now Serving</p>
          <h3 className="text-2xl font-bold text-foreground">{serving} Counters</h3>
        </div>
      </div>
    </div>
  );
}
