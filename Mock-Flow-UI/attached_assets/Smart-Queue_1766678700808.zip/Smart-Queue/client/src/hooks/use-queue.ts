import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { 
  type Center, 
  type QueueItem, 
  type JoinQueueRequest, 
  type PredictWaitRequest,
  type PredictionResponse 
} from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

// Fetch all centers
export function useCenters() {
  return useQuery({
    queryKey: [api.centers.list.path],
    queryFn: async () => {
      const res = await fetch(api.centers.list.path);
      if (!res.ok) throw new Error("Failed to fetch centers");
      return api.centers.list.responses[200].parse(await res.json());
    },
  });
}

// Fetch queue for a specific center
export function useQueue(centerId: number) {
  return useQuery({
    queryKey: [api.queue.list.path, centerId],
    queryFn: async () => {
      const url = buildUrl(api.queue.list.path, { centerId });
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch queue");
      return api.queue.list.responses[200].parse(await res.json());
    },
    enabled: !!centerId,
    refetchInterval: 5000, // Live updates every 5s
  });
}

// Join Queue Mutation
export function useJoinQueue() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: JoinQueueRequest) => {
      const res = await fetch(api.queue.join.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to join queue");
      }
      return api.queue.join.responses[201].parse(await res.json());
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [api.queue.list.path, data.centerId] });
      toast({
        title: "Joined Queue Successfully!",
        description: `Your token number is ${data.tokenNumber}`,
      });
    },
    onError: (err) => {
      toast({
        title: "Error Joining Queue",
        description: err.message,
        variant: "destructive",
      });
    }
  });
}

// AI Predictor Mutation
export function usePredictWait() {
  return useMutation({
    mutationFn: async (data: PredictWaitRequest) => {
      const res = await fetch(api.queue.predict.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      
      if (!res.ok) throw new Error("Failed to get prediction");
      return api.queue.predict.responses[200].parse(await res.json());
    },
  });
}

// Admin: Call Next
export function useCallNext() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (centerId: number) => {
      const url = buildUrl(api.queue.callNext.path, { centerId });
      const res = await fetch(url, { method: "POST" });
      if (!res.ok) throw new Error("Failed to call next person");
      return res.json();
    },
    onSuccess: (_, centerId) => {
      queryClient.invalidateQueries({ queryKey: [api.queue.list.path, centerId] });
      toast({ title: "Called next person" });
    },
  });
}
