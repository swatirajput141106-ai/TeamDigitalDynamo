import { useState } from "react";
import { useCenters, useQueue, useCallNext } from "@/hooks/use-queue";
import { Header } from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Loader2, Megaphone, CheckCircle, RefreshCcw } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Admin() {
  const { data: centers, isLoading: loadingCenters } = useCenters();
  const [selectedCenterId, setSelectedCenterId] = useState<number | null>(null);

  if (centers && centers.length > 0 && selectedCenterId === null) {
    setSelectedCenterId(centers[0].id);
  }

  const { data: queue = [] } = useQueue(selectedCenterId || 0);
  const { mutate: callNext, isPending: isCalling } = useCallNext();

  const waitingQueue = queue.filter((q) => q.status === "waiting");
  const servingQueue = queue.filter((q) => q.status === "serving");

  if (loadingCenters) {
    return <div className="h-screen flex items-center justify-center"><Loader2 className="animate-spin" /></div>;
  }

  return (
    <div className="min-h-screen bg-muted/20 font-sans">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold font-display">Admin Console</h1>
          <div className="flex gap-2">
            {centers?.map(c => (
              <Button
                key={c.id}
                variant={selectedCenterId === c.id ? "default" : "outline"}
                onClick={() => setSelectedCenterId(c.id)}
                className="rounded-lg"
              >
                {c.name}
              </Button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Controls */}
          <div className="space-y-6">
            <div className="bg-white p-8 rounded-2xl border shadow-sm">
              <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
                <Megaphone className="w-6 h-6 text-primary" /> Counter Controls
              </h2>
              
              <div className="flex flex-col gap-4">
                <div className="p-4 bg-amber-50 rounded-xl border border-amber-100 mb-4">
                  <div className="text-sm text-amber-900 font-medium mb-1">Queue Status</div>
                  <div className="text-3xl font-bold text-amber-700">
                    {waitingQueue.length} <span className="text-base font-normal text-amber-600">waiting</span>
                  </div>
                </div>

                <Button 
                  size="lg" 
                  className="w-full h-20 text-xl shadow-xl shadow-primary/20"
                  onClick={() => selectedCenterId && callNext(selectedCenterId)}
                  disabled={isCalling || waitingQueue.length === 0}
                >
                  {isCalling ? (
                    <><Loader2 className="mr-3 h-6 w-6 animate-spin" /> Processing...</>
                  ) : (
                    <><Megaphone className="mr-3 h-6 w-6" /> Call Next Person</>
                  )}
                </Button>
                
                <p className="text-center text-sm text-muted-foreground">
                  Pressing this will assign the next waiting person to an available counter.
                </p>
              </div>
            </div>

            <div className="bg-white p-6 rounded-2xl border shadow-sm">
              <h3 className="font-bold mb-4">Currently Serving</h3>
              <div className="space-y-3">
                {servingQueue.length === 0 ? (
                  <p className="text-muted-foreground text-sm italic">No one is currently being served.</p>
                ) : (
                  servingQueue.map(item => (
                    <div key={item.id} className="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-100">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-green-200 text-green-800 flex items-center justify-center font-bold text-xs">
                          {item.tokenNumber}
                        </div>
                        <div>
                          <p className="text-sm font-medium">{item.citizenName}</p>
                          <p className="text-xs text-muted-foreground">Counter {item.counterAssigned}</p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" className="h-8 text-xs border-green-200 hover:bg-green-100 text-green-700">
                          <CheckCircle className="w-3 h-3 mr-1" /> Complete
                        </Button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* List View */}
          <div className="bg-white rounded-2xl border shadow-sm overflow-hidden flex flex-col h-[600px]">
            <div className="p-4 border-b bg-muted/30 flex justify-between items-center">
              <h3 className="font-bold">Full Queue List</h3>
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <RefreshCcw className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex-1 overflow-y-auto">
              <table className="w-full text-sm text-left">
                <thead className="text-xs text-muted-foreground bg-muted/50 uppercase sticky top-0">
                  <tr>
                    <th className="px-4 py-3 font-medium">Token</th>
                    <th className="px-4 py-3 font-medium">Name</th>
                    <th className="px-4 py-3 font-medium">Service</th>
                    <th className="px-4 py-3 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {queue.map((item) => (
                    <tr key={item.id} className="hover:bg-muted/20 transition-colors">
                      <td className="px-4 py-3 font-mono font-medium">{item.tokenNumber}</td>
                      <td className="px-4 py-3">{item.citizenName}</td>
                      <td className="px-4 py-3 text-muted-foreground">{item.serviceType}</td>
                      <td className="px-4 py-3">
                        <span className={cn(
                          "px-2 py-0.5 rounded-full text-xs font-medium uppercase",
                          item.status === 'waiting' ? "bg-amber-100 text-amber-700" :
                          item.status === 'serving' ? "bg-green-100 text-green-700" :
                          "bg-slate-100 text-slate-700"
                        )}>
                          {item.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                  {queue.length === 0 && (
                    <tr>
                      <td colSpan={4} className="p-8 text-center text-muted-foreground">
                        No records found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
