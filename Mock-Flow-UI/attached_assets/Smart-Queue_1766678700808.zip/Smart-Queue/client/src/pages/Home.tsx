import { useState } from "react";
import { useCenters, useQueue } from "@/hooks/use-queue";
import { Header } from "@/components/Header";
import { QueueStats } from "@/components/QueueStats";
import { JoinQueueDialog } from "@/components/JoinQueueDialog";
import { AIPredictor } from "@/components/AIPredictor";
import { MapPin, ArrowRight, User, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";

export default function Home() {
  const { data: centers, isLoading: loadingCenters } = useCenters();
  const [selectedCenterId, setSelectedCenterId] = useState<number | null>(null);

  // If centers load and none selected, select first
  if (centers && centers.length > 0 && selectedCenterId === null) {
    setSelectedCenterId(centers[0].id);
  }

  const { data: queue = [] } = useQueue(selectedCenterId || 0);

  // Separate queues
  const waitingQueue = queue.filter((q) => q.status === "waiting");
  const servingQueue = queue.filter((q) => q.status === "serving");

  const selectedCenter = centers?.find((c) => c.id === selectedCenterId);

  if (loadingCenters) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background font-sans">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Sidebar - Center Selection */}
          <div className="lg:col-span-3 space-y-4">
            <h2 className="text-lg font-bold text-foreground mb-4 px-2">Service Centers</h2>
            <div className="space-y-3">
              {centers?.map((center) => (
                <div
                  key={center.id}
                  onClick={() => setSelectedCenterId(center.id)}
                  className={cn(
                    "p-4 rounded-xl cursor-pointer transition-all duration-200 border",
                    selectedCenterId === center.id
                      ? "bg-primary text-primary-foreground border-primary shadow-lg shadow-primary/20 ring-2 ring-primary ring-offset-2"
                      : "bg-white hover:bg-muted border-border hover:border-primary/50 text-foreground"
                  )}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-bold text-sm">{center.name}</h3>
                      <div className="flex items-center gap-1 mt-1 text-xs opacity-80">
                        <MapPin className="w-3 h-3" />
                        {center.address}
                      </div>
                    </div>
                    {selectedCenterId === center.id && <div className="h-2 w-2 rounded-full bg-white animate-pulse" />}
                  </div>
                  <div className="mt-3 flex items-center gap-2 text-xs font-medium opacity-90">
                    <span className="bg-black/10 px-2 py-0.5 rounded-md">
                      {center.activeCounters} Counters
                    </span>
                    <span className="bg-black/10 px-2 py-0.5 rounded-md">
                      Wait: ~{center.avgServiceTime}m
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Main Content - Queue Display */}
          <div className="lg:col-span-6">
            <div className="mb-6">
              <h1 className="text-3xl font-bold font-display text-foreground">
                {selectedCenter?.name}
              </h1>
              <p className="text-muted-foreground mt-1">Live Queue Status Dashboard</p>
            </div>

            {/* Stats Cards */}
            <QueueStats 
              queue={queue} 
              avgServiceTime={selectedCenter?.avgServiceTime || 10} 
            />

            {/* Live Queue Table */}
            <div className="bg-white rounded-2xl border shadow-sm overflow-hidden">
              <div className="p-4 border-b bg-muted/30 flex items-center justify-between">
                <h3 className="font-semibold text-foreground flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                  Currently Serving
                </h3>
              </div>
              <div className="divide-y">
                {servingQueue.length === 0 ? (
                  <div className="p-8 text-center text-muted-foreground">
                    All counters are free or closed.
                  </div>
                ) : (
                  servingQueue.map((item) => (
                    <div key={item.id} className="p-4 flex items-center justify-between bg-green-50/50">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-full bg-green-100 text-green-700 font-bold flex items-center justify-center text-sm border-2 border-green-200">
                          {item.tokenNumber}
                        </div>
                        <div>
                          <p className="font-medium text-foreground">{item.citizenName}</p>
                          <p className="text-xs text-green-700 font-medium">{item.serviceType}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-xs font-bold uppercase text-green-600 bg-green-100 px-2 py-1 rounded-full">
                          Counter {item.counterAssigned}
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="mt-6 bg-white rounded-2xl border shadow-sm overflow-hidden">
              <div className="p-4 border-b bg-muted/30">
                <h3 className="font-semibold text-foreground">Up Next in Queue</h3>
              </div>
              <div className="divide-y max-h-[400px] overflow-y-auto">
                <AnimatePresence>
                  {waitingQueue.length === 0 ? (
                    <div className="p-8 text-center text-muted-foreground">
                      Queue is empty! Join now to be first.
                    </div>
                  ) : (
                    waitingQueue.map((item, index) => (
                      <motion.div
                        key={item.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, height: 0 }}
                        className="p-4 flex items-center justify-between hover:bg-muted/40 transition-colors"
                      >
                        <div className="flex items-center gap-4">
                          <span className="text-xs font-mono text-muted-foreground w-6">#{index + 1}</span>
                          <div className="w-10 h-10 rounded-full bg-muted text-muted-foreground font-bold flex items-center justify-center text-sm border border-border">
                            {item.tokenNumber}
                          </div>
                          <div>
                            <p className="font-medium text-foreground">{item.citizenName}</p>
                            <p className="text-xs text-muted-foreground">{item.serviceType}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground bg-muted px-2 py-1 rounded-md">
                          <User className="w-3 h-3" /> Waiting
                        </div>
                      </motion.div>
                    ))
                  )}
                </AnimatePresence>
              </div>
            </div>
          </div>

          {/* Right Sidebar - Actions & AI */}
          <div className="lg:col-span-3 space-y-6">
            <div className="bg-white p-6 rounded-2xl border shadow-sm">
              <h3 className="font-bold text-lg mb-4">Quick Actions</h3>
              {selectedCenterId && <JoinQueueDialog centerId={selectedCenterId} />}
              <p className="text-xs text-muted-foreground mt-3 text-center">
                Average wait time is based on current traffic.
              </p>
            </div>

            {selectedCenterId && <AIPredictor centerId={selectedCenterId} />}
            
            <div className="p-4 rounded-xl bg-blue-50 border border-blue-100 text-blue-900 text-sm">
              <h4 className="font-bold mb-2 flex items-center gap-2">
                <InfoIcon className="w-4 h-4" /> Did you know?
              </h4>
              <p className="opacity-90 text-xs leading-relaxed">
                You can check real-time updates here before leaving your home to minimize wait times.
              </p>
            </div>
          </div>

        </div>
      </main>
    </div>
  );
}

function InfoIcon(props: any) {
  return (
    <svg 
      {...props}
      xmlns="http://www.w3.org/2000/svg" 
      width="24" height="24" viewBox="0 0 24 24" 
      fill="none" stroke="currentColor" strokeWidth="2" 
      strokeLinecap="round" strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/>
    </svg>
  );
}
