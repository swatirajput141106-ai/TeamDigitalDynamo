import { Header } from "@/components/Header";

export default function About() {
  return (
    <div className="min-h-screen bg-background font-sans">
      <Header />
      <main className="container mx-auto px-4 py-16 max-w-2xl text-center">
        <h1 className="text-4xl font-bold font-display mb-6 text-foreground">
          About SmartQueue
        </h1>
        <p className="text-lg text-muted-foreground leading-relaxed mb-8">
          SmartQueue is an AI-driven solution designed to streamline government service delivery. 
          By leveraging real-time data and predictive analytics powered by Gemini AI, 
          we reduce wait times and improve citizen satisfaction.
        </p>
        
        <div className="bg-white p-8 rounded-2xl border shadow-sm text-left">
          <h2 className="text-xl font-bold mb-4">Key Features</h2>
          <ul className="space-y-3">
            <li className="flex items-center gap-3">
              <div className="w-2 h-2 rounded-full bg-primary" />
              <span>Real-time queue tracking</span>
            </li>
            <li className="flex items-center gap-3">
              <div className="w-2 h-2 rounded-full bg-primary" />
              <span>AI-powered wait time predictions</span>
            </li>
            <li className="flex items-center gap-3">
              <div className="w-2 h-2 rounded-full bg-primary" />
              <span>Remote token generation</span>
            </li>
            <li className="flex items-center gap-3">
              <div className="w-2 h-2 rounded-full bg-primary" />
              <span>Efficient counter management for admins</span>
            </li>
          </ul>
        </div>
        
        <div className="mt-12 pt-8 border-t">
          <p className="text-sm text-muted-foreground">
            Built for the Replit AI Hackathon • 2024
          </p>
        </div>
      </main>
    </div>
  );
}
