import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { GoogleGenAI } from "@google/genai";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Gemini Setup
  // Using Replit AI Integrations with the new @google/genai SDK
  const genAI = new GoogleGenAI({
    apiKey: process.env.AI_INTEGRATIONS_GEMINI_API_KEY || "mock-key",
    httpOptions: {
      apiVersion: "v1beta", // or empty string as per blueprint? Blueprint says ""
      baseUrl: process.env.AI_INTEGRATIONS_GEMINI_BASE_URL,
    },
  });

  app.get(api.centers.list.path, async (req, res) => {
    const centers = await storage.getCenters();
    res.json(centers);
  });

  app.get("/api/queue/:centerId", async (req, res) => {
    const centerId = parseInt(req.params.centerId);
    const queue = await storage.getQueue(centerId);
    res.json(queue);
  });

  app.post(api.queue.join.path, async (req, res) => {
    try {
      const input = api.queue.join.input.parse(req.body);
      const queue = await storage.getQueue(input.centerId);
      const waitTime = (queue.filter(q => q.status === 'waiting').length + 1) * 10; // Simple logic
      
      const item = await storage.joinQueue({
        ...input,
        tokenNumber: `W${Math.floor(Math.random() * 900) + 100}`,
        estimatedWait: waitTime,
        status: "waiting",
        counterAssigned: null
      });
      res.status(201).json(item);
    } catch (err) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  app.post(api.queue.predict.path, async (req, res) => {
    try {
      const { centerId, serviceType } = api.queue.predict.input.parse(req.body);
      
      const centers = await storage.getCenters();
      const center = centers.find(c => c.id === centerId);
      const queue = await storage.getQueue(centerId);
      
      if (!center) throw new Error("Center not found");

      // Construct prompt
      const prompt = `
        Context: Queue management system for ${center.name}.
        Current Stats:
        - Active Counters: ${center.activeCounters}
        - Current Queue Length: ${queue.length}
        - Service Type Requested: ${serviceType}
        - Time of Day: ${new Date().toLocaleTimeString()}
        
        Task: Predict wait time and rush level.
        Return ONLY valid JSON: {"waitMinutes": number, "rushLevel": "low"|"medium"|"high", "tip": "string"}
      `;

      let result;
      try {
        if (!process.env.AI_INTEGRATIONS_GEMINI_API_KEY) {
           console.warn("No AI Key found, using mock data");
           throw new Error("No API Key");
        }
        
        const response = await genAI.models.generateContent({
          model: "gemini-1.5-flash",
          contents: [{ role: "user", parts: [{ text: prompt }] }],
        });
        
        const text = response.response.text();
        // clean up code blocks if gemini adds them
        const jsonStr = text.replace(/```json/g, '').replace(/```/g, '').trim();
        result = JSON.parse(jsonStr);
      } catch (e) {
        console.error("Gemini API error or missing key:", e);
        // Fallback mock prediction
        result = {
          waitMinutes: Math.floor(Math.random() * 20) + 10,
          rushLevel: "medium",
          tip: "This is a fallback prediction (AI unavailable)."
        };
      }

      res.json(result);
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: "Prediction failed" });
    }
  });

  app.post("/api/queue/:centerId/next", async (req, res) => {
    const centerId = parseInt(req.params.centerId);
    const queue = await storage.getQueue(centerId);
    const nextItem = queue.find(q => q.status === 'waiting');
    
    if (nextItem) {
      await storage.updateQueueStatus(nextItem.id, 'serving', 1);
      res.json({ success: true });
    } else {
      res.json({ success: false });
    }
  });

  return httpServer;
}
