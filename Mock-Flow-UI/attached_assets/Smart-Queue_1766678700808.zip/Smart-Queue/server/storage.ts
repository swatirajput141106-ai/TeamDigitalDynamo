import { centers, queue, type Center, type QueueItem, type InsertCenter, type InsertQueueItem } from "@shared/schema";

export interface IStorage {
  getCenters(): Promise<Center[]>;
  getQueue(centerId: number): Promise<QueueItem[]>;
  joinQueue(item: InsertQueueItem): Promise<QueueItem>;
  updateQueueStatus(id: number, status: string, counter?: number): Promise<void>;
  getQueueItem(id: number): Promise<QueueItem | undefined>;
}

export class MemStorage implements IStorage {
  private centers: Center[];
  private queue: QueueItem[];
  private centerIdCounter = 1;
  private queueIdCounter = 1;

  constructor() {
    this.centers = [
      {
        id: 1,
        name: "City Center Civic Office",
        address: "123 Main St, Metro City",
        lat: "40.7128",
        lng: "-74.0060",
        totalCounters: 5,
        activeCounters: 4,
        avgServiceTime: 12,
        currentQueueLength: 0
      },
      {
        id: 2,
        name: "Suburban Service Hub",
        address: "456 Park Ave, Greenfield",
        lat: "40.7580",
        lng: "-73.9855",
        totalCounters: 3,
        activeCounters: 2,
        avgServiceTime: 15,
        currentQueueLength: 0
      },
      {
        id: 3,
        name: "Downtown Express",
        address: "789 Broadway, Downtown",
        lat: "40.7829",
        lng: "-73.9654",
        totalCounters: 4,
        activeCounters: 3,
        avgServiceTime: 10,
        currentQueueLength: 0
      }
    ];

    this.queue = [];
    
    // Seed some queue data
    this.seedQueue();
  }

  private seedQueue() {
    const samples = [
      { centerId: 1, name: "Rahul Sharma", service: "Document Verification", status: "serving" },
      { centerId: 1, name: "Priya Patel", service: "New Application", status: "waiting" },
      { centerId: 1, name: "Amit Kumar", service: "Payment & Fees", status: "waiting" },
      { centerId: 2, name: "Sneha Gupta", service: "Certificate Collection", status: "waiting" },
    ];

    samples.forEach((s, i) => {
      this.queue.push({
        id: this.queueIdCounter++,
        centerId: s.centerId,
        tokenNumber: `A${100 + i}`,
        citizenName: s.name,
        phone: "555-010" + i,
        serviceType: s.service,
        status: s.status,
        counterAssigned: s.status === 'serving' ? 1 : null,
        joinTime: new Date(Date.now() - i * 1000 * 60 * 5),
        estimatedWait: s.status === 'serving' ? 0 : (i + 1) * 10
      });
    });
  }

  async getCenters(): Promise<Center[]> {
    // Update queue lengths dynamically
    return this.centers.map(c => ({
      ...c,
      currentQueueLength: this.queue.filter(q => q.centerId === c.id && q.status === 'waiting').length
    }));
  }

  async getQueue(centerId: number): Promise<QueueItem[]> {
    return this.queue.filter(q => q.centerId === centerId);
  }

  async joinQueue(item: InsertQueueItem): Promise<QueueItem> {
    const newItem: QueueItem = {
      ...item,
      id: this.queueIdCounter++,
      id: this.queueIdCounter, // fix types
      joinTime: new Date(),
      counterAssigned: null,
      status: "waiting"
    };
    // Fix estimated wait logic in real app, simplistic here
    this.queue.push(newItem);
    return newItem;
  }

  async updateQueueStatus(id: number, status: string, counter?: number): Promise<void> {
    const item = this.queue.find(q => q.id === id);
    if (item) {
      item.status = status;
      if (counter) item.counterAssigned = counter;
    }
  }

  async getQueueItem(id: number): Promise<QueueItem | undefined> {
    return this.queue.find(q => q.id === id);
  }
}

export const storage = new MemStorage();
